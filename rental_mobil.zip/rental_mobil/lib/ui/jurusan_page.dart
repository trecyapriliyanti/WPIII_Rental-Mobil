import 'package:flutter/material.dart';
import '../widget/sidebar.dart';
import '../model/jurusan.dart';
import 'jurusan_item.dart';
import 'jurusan_form.dart';

class JurusanPage extends StatefulWidget {
  const JurusanPage({Key? key}) : super(key: key);

  @override
  State<JurusanPage> createState() => _JurusanPageState();
}

class _JurusanPageState extends State<JurusanPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Sidebar(),
      appBar: AppBar(
        title: const Text("Data Jurusan"),
        actions: [
          GestureDetector(
            child: const Icon(Icons.add),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => JurusanForm()),
              );
            },
          )
        ],
      ),
      body: ListView(
        children: [
          JurusanItem(jurusan: Jurusan(namaJurusan: "Sistem Informasi")),
          JurusanItem(jurusan: Jurusan(namaJurusan: "Teknologi Informasi")),
          JurusanItem(jurusan: Jurusan(namaJurusan: "Teknik Informatika")),
          JurusanItem(jurusan: Jurusan(namaJurusan: "Data Sains")),
        ],
      ),
    );
  }
}
