import 'package:flutter/material.dart';
import '../model/mahasiswa.dart';
import 'mahasiswa_update_form.dart';
import 'mahasiswa_page.dart';

class MahasiswaDetail extends StatefulWidget {
  final Mahasiswa mahasiswa;

  const MahasiswaDetail({Key? key, required this.mahasiswa}) : super(key: key);

  @override
  _MahasiswaDetailState createState() => _MahasiswaDetailState();
}

class _MahasiswaDetailState extends State<MahasiswaDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Mahasiswa'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('NIM        : ${widget.mahasiswa.nim}'),
            SizedBox(height: 8.0),
            Text('Nama        : ${widget.mahasiswa.nama}'),
            SizedBox(height: 8.0),
            Text('Alamat         : ${widget.mahasiswa.alamat}'),
            SizedBox(height: 8.0),
            Text('No Telpon : ${widget.mahasiswa.no_telpon.toString()}'),
            SizedBox(height: 8.0),
            Text('Jurusan : ${widget.mahasiswa.jurusan}'),
            SizedBox(height: 8.0),
            Text('Semester        : ${widget.mahasiswa.semester}'),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            MahasiswaUpdateForm(mahasiswa: widget.mahasiswa),
                      ),
                    );
                  },
                  style:
                      ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: const Text("Ubah"),
                ),
                ElevatedButton(
                  onPressed: () {
                    AlertDialog alertDialog = AlertDialog(
                      content: const Text("Yakin ingin menghapus data ini?"),
                      actions: [
                        ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => MahasiswaPage()),
                            );
                          },
                          child: const Text("YA"),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: const Text("Tidak"),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green),
                        ),
                      ],
                    );
                    showDialog(
                        context: context, builder: (context) => alertDialog);
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: const Text("Hapus"),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
