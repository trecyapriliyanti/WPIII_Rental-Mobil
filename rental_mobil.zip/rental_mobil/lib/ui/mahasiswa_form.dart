import '/model/mahasiswa.dart';
import 'package:flutter/material.dart';
import 'mahasiswa_detail.dart';

class MahasiswaForm extends StatefulWidget {
  const MahasiswaForm({Key? key}) : super(key: key);

  @override
  _MahasiswaFormState createState() => _MahasiswaFormState();
}

class _MahasiswaFormState extends State<MahasiswaForm> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nimCtrl = TextEditingController();
  final TextEditingController _namaCtrl = TextEditingController();
  final TextEditingController _alamatCtrl = TextEditingController();
  final TextEditingController _no_telponCtrl = TextEditingController();
  final TextEditingController _jurusanCtrl = TextEditingController();
  final TextEditingController _semesterCtrl = TextEditingController();

  @override
  void dispose() {
    _nimCtrl.dispose();
    _namaCtrl.dispose();
    _alamatCtrl.dispose();
    _no_telponCtrl.dispose();
    _jurusanCtrl.dispose();
    _semesterCtrl.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Tambah Mahasiswa")),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: "NIM"),
                controller: _nimCtrl,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Nama"),
                controller: _namaCtrl,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Alamat"),
                controller: _alamatCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Alamat tidak boleh kosong";
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "No Telpon"),
                controller: _no_telponCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Nomor Telpon tidak boleh kosong";
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Jurusan"),
                controller: _jurusanCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Jurusan tidak boleh kosong";
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Semester"),
                controller: _semesterCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Semester tidak boleh kosong";
                  }
                  return null;
                },
              ),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    Mahasiswa mahasiswa = Mahasiswa(
                      nim: _nimCtrl.text,
                      nama: _namaCtrl.text,
                      alamat: _alamatCtrl.text,
                      no_telpon: _no_telponCtrl.text,
                      jurusan: _jurusanCtrl.text,
                      semester: _semesterCtrl.text,
                    );
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            MahasiswaDetail(mahasiswa: mahasiswa),
                      ),
                    );
                  }
                },
                child: const Text("Simpan"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
