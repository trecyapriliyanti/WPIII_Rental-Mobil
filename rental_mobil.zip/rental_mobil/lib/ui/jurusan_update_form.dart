import 'package:flutter/material.dart';
import '../model/jurusan.dart';
import '/ui/jurusan_detail.dart';

class JurusanUpdateForm extends StatefulWidget {
  final Jurusan jurusan;

  const JurusanUpdateForm({required this.jurusan}) : super();

  @override
  _JurusanUpdateFormState createState() => _JurusanUpdateFormState();
}

class _JurusanUpdateFormState extends State<JurusanUpdateForm> {
  final _namaJurusanCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _namaJurusanCtrl.text = widget.jurusan.namaJurusan;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Ubah Jurusan")),
      body: SingleChildScrollView(
        child: Form(
          child: Column(
            children: [
              _fieldNamaJurusan(),
              SizedBox(height: 20),
              _tombolSimpan(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _fieldNamaJurusan() {
    return TextField(
      decoration: const InputDecoration(labelText: "Nama Jurusan"),
      controller: _namaJurusanCtrl,
    );
  }

  Widget _tombolSimpan() {
    return ElevatedButton(
      onPressed: () {
        Jurusan jurusan = Jurusan(namaJurusan: _namaJurusanCtrl.text);
        Navigator.pop(context);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => JurusanDetail(jurusan: jurusan),
          ),
        );
      },
      child: const Text("Simpan Perubahan"),
    );
  }
}
