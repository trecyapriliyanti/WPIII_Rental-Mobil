import 'package:flutter/material.dart';
import 'dosen_detail.dart';
import '../model/dosen.dart';
import 'dosen_form.dart';
import '../widget/sidebar.dart';

class DosenPage extends StatefulWidget {
  const DosenPage({Key? key}); // Perbaikan penulisan parameter key

  @override
  _DosenPageState createState() => _DosenPageState();
}

class _DosenPageState extends State<DosenPage> {
  final List<Dosen> _dosen = [
    Dosen(
      kd_dosen: 'EGS',
      nama: 'Erene Gernaria Sihombing',
      pendidikan_terakhir: 'S2',
      alamat: 'Jatiwaringin',
      no_telp: '086546532357',
      email: 'erenegernaria@gmail.com',
    ),
    Dosen(
      kd_dosen: 'HRO',
      nama: 'Hariyanto',
      pendidikan_terakhir: 'S2',
      alamat: 'Jakarta Barat',
      no_telp: '08653173183',
      email: 'hariyanto.bsi.ac.id',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Sidebar(),
      appBar: AppBar(
        title: const Text("Data Dosen"),
        actions: [
          GestureDetector(
            child: const Icon(Icons.add),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => DosenForm()),
              );
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: _dosen.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DosenDetail(dosen: _dosen[index]),
                ),
              );
            },
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.grey,
                  width: 0.5,
                ),
              ),
              child: ListTile(
                title: Text(_dosen[index].nama),
                subtitle: Text('Kode Dosen: ${_dosen[index].kd_dosen}'),
              ),
            ),
          );
        },
      ),
    );
  }
}
