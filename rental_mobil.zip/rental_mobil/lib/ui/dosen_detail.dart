import 'package:flutter/material.dart';
import '../model/dosen.dart';
import 'dosen_update_form.dart';
import 'dosen_page.dart';

class DosenDetail extends StatelessWidget {
  final Dosen dosen;

  const DosenDetail({Key? key, required this.dosen});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Dosen'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Kode Dosen        : ${dosen.kd_dosen}'),
            SizedBox(height: 8.0),
            Text('Nama Dosen        : ${dosen.nama}'),
            SizedBox(height: 8.0),
            Text(
                'Pendidikan Terakhir : ${dosen.pendidikan_terakhir.toString()}'),
            SizedBox(height: 8.0),
            Text('Alamat        :    ${dosen.alamat}'),
            SizedBox(height: 8.0),
            Text('No Telpon        : ${dosen.no_telp}'),
            SizedBox(height: 20),
            Text('Email        : ${dosen.email}'),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DosenUpdateForm(dosen: dosen),
                      ),
                    );
                  },
                  style:
                      ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: const Text("Ubah"),
                ),
                ElevatedButton(
                  onPressed: () {
                    AlertDialog alertDialog = AlertDialog(
                      content: const Text("Yakin ingin menghapus data ini?"),
                      actions: [
                        ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => DosenPage()),
                            );
                          },
                          child: const Text("YA"),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: const Text("Tidak"),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green),
                        ),
                      ],
                    );
                    showDialog(
                        context: context, builder: (context) => alertDialog);
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: const Text("Hapus"),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
