import 'package:flutter/material.dart';
import '../model/dosen.dart';
import '/ui/dosen_detail.dart';

class DosenUpdateForm extends StatefulWidget {
  final Dosen dosen;

  const DosenUpdateForm({required this.dosen}) : super();

  @override
  _DosenUpdateFormState createState() => _DosenUpdateFormState();
}

class _DosenUpdateFormState extends State<DosenUpdateForm> {
  final _kd_dosenCtrl = TextEditingController();
  final _namaCtrl = TextEditingController();
  final _pendidikan_terakhirCtrl = TextEditingController();
  final _alamatCtrl = TextEditingController();
  final _no_telpCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _kd_dosenCtrl.text = widget.dosen.kd_dosen;
    _namaCtrl.text = widget.dosen.nama;
    _pendidikan_terakhirCtrl.text = widget.dosen.pendidikan_terakhir;
    _alamatCtrl.text = widget.dosen.alamat;
    _no_telpCtrl.text = widget.dosen.no_telp;
    _emailCtrl.text = widget.dosen.email;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Ubah Poli")),
      body: SingleChildScrollView(
        child: Form(
          child: Column(
            children: [
              _fieldKd_dosen(),
              _fieldNama(),
              _fieldAlamat(),
              _fieldNo_telp(),
              _fieldPendidikan(),
              _fieldEmail(),
              SizedBox(height: 20),
              _tombolSimpan(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _fieldKd_dosen() {
    return TextField(
      decoration: const InputDecoration(labelText: "Kode Dosen"),
      controller: _kd_dosenCtrl,
    );
  }

  Widget _fieldNama() {
    return TextField(
      decoration: const InputDecoration(labelText: "Nama"),
      controller: _namaCtrl,
    );
  }

  Widget _fieldPendidikan() {
    return TextField(
      decoration: const InputDecoration(labelText: "Pendidikan Terakhir"),
      controller: _pendidikan_terakhirCtrl,
    );
  }

  Widget _fieldAlamat() {
    return TextField(
      decoration: const InputDecoration(labelText: "Alamat "),
      controller: _alamatCtrl,
    );
  }

  Widget _fieldNo_telp() {
    return TextField(
      decoration: const InputDecoration(labelText: "No Telepon"),
      controller: _no_telpCtrl,
    );
  }

  Widget _fieldEmail() {
    return TextField(
      decoration: const InputDecoration(labelText: "Email"),
      controller: _emailCtrl,
    );
  }

  Widget _tombolSimpan() {
    return ElevatedButton(
      onPressed: () {
        Dosen dosen = Dosen(
          kd_dosen: _kd_dosenCtrl.text,
          nama: _namaCtrl.text,
          pendidikan_terakhir: _pendidikan_terakhirCtrl.text,
          alamat: _alamatCtrl.text,
          no_telp: _no_telpCtrl.text,
          email: _emailCtrl.text,
        );
        Navigator.pop(context);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => DosenDetail(dosen: dosen),
          ),
        );
      },
      child: const Text("Simpan Perubahan"),
    );
  }
}
