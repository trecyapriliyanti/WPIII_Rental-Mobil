import '/model/dosen.dart';
import 'package:flutter/material.dart';
import 'dosen_detail.dart';

class DosenForm extends StatefulWidget {
  const DosenForm({Key? key}) : super(key: key);

  @override
  _DosenFormState createState() => _DosenFormState();
}

class _DosenFormState extends State<DosenForm> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _kd_dosenCtrl = TextEditingController();
  final TextEditingController _namaCtrl = TextEditingController();
  final TextEditingController _pendidikan_terakhirCtrl =
      TextEditingController();
  final TextEditingController _alamatCtrl = TextEditingController();
  final TextEditingController _no_telpCtrl = TextEditingController();
  final TextEditingController _emailCtrl = TextEditingController();

  @override
  void dispose() {
    _kd_dosenCtrl.dispose();
    _namaCtrl.dispose();
    _pendidikan_terakhirCtrl.dispose();
    _alamatCtrl.dispose();
    _no_telpCtrl.dispose();
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Tambah Mahasiswa")),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: "Kode Dosen"),
                controller: _kd_dosenCtrl,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Nama Dosen"),
                controller: _namaCtrl,
              ),
              TextFormField(
                decoration:
                    const InputDecoration(labelText: "Pendidikan Terakhir"),
                controller: _pendidikan_terakhirCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Pendidikan terakhir tidak boleh kosong";
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Alamat"),
                controller: _alamatCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Alamat tidak boleh kosong";
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "No Telpon"),
                controller: _no_telpCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Nomor Telpon tidak boleh kosong";
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "No.Telpon"),
                controller: _emailCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Email tidak boleh kosong";
                  }
                  return null;
                },
              ),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    Dosen dosen = Dosen(
                      kd_dosen: _kd_dosenCtrl.text,
                      nama: _namaCtrl.text,
                      pendidikan_terakhir: _pendidikan_terakhirCtrl.text,
                      alamat: _alamatCtrl.text,
                      no_telp: _no_telpCtrl.text,
                      email: _emailCtrl.text,
                    );
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DosenDetail(dosen: dosen),
                      ),
                    );
                  }
                },
                child: const Text("Simpan"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
