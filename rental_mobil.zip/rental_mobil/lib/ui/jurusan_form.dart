import 'package:flutter/material.dart';
import '/model/jurusan.dart';
import '/ui/jurusan_detail.dart';

class JurusanForm extends StatefulWidget {
  const JurusanForm({Key? key}) : super(key: key);

  _JurusanFormState createState() => _JurusanFormState();
}

class _JurusanFormState extends State<JurusanForm> {
  final _formKey = GlobalKey<FormState>();
  final _namaJurusanCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Tambah Jurusan")),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _fieldNamaJurusan(),
              const SizedBox(height: 20),
              _tombolSimpan(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _fieldNamaJurusan() {
    return TextFormField(
      decoration: const InputDecoration(labelText: "Nama Jurusan"),
      controller: _namaJurusanCtrl,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Nama  harus diisi';
        }
        return null;
      },
    );
  }

  Widget _tombolSimpan() {
    return ElevatedButton(
      onPressed: () {
        if (_formKey.currentState!.validate()) {
          Jurusan jurusan = Jurusan(namaJurusan: _namaJurusanCtrl.text);
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => JurusanDetail(jurusan: jurusan)));
        }
      },
      child: const Text("Simpan"),
    );
  }
}
