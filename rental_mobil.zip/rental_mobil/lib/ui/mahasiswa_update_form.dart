import 'package:flutter/material.dart';
import '../model/mahasiswa.dart';
import '/ui/mahasiswa_detail.dart';

class MahasiswaUpdateForm extends StatefulWidget {
  final Mahasiswa mahasiswa;

  const MahasiswaUpdateForm({required this.mahasiswa}) : super();

  @override
  _MahasiswaUpdateFormState createState() => _MahasiswaUpdateFormState();
}

class _MahasiswaUpdateFormState extends State<MahasiswaUpdateForm> {
  final _nimCtrl = TextEditingController();

  final _namaCtrl = TextEditingController();
  final _alamatCtrl = TextEditingController();
  final _no_telponCtrl = TextEditingController();
  final _jurusanCtrl = TextEditingController();
  final _semesterCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _nimCtrl.text = widget.mahasiswa.nim;
    _namaCtrl.text = widget.mahasiswa.nama;
    _alamatCtrl.text = widget.mahasiswa.alamat;
    _no_telponCtrl.text = widget.mahasiswa.no_telpon;
    _jurusanCtrl.text = widget.mahasiswa.jurusan;
    _semesterCtrl.text = widget.mahasiswa.semester;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Ubah Poli")),
      body: SingleChildScrollView(
        child: Form(
          child: Column(
            children: [
              _fieldNim(),
              _fieldNama(),
              _fieldNo_telpon(),
              _fieldJurusan(),
              _fieldSemester(),
              SizedBox(height: 20),
              _tombolSimpan(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _fieldNim() {
    return TextField(
      decoration: const InputDecoration(labelText: "NIP"),
      controller: _nimCtrl,
    );
  }

  Widget _fieldNama() {
    return TextField(
      decoration: const InputDecoration(labelText: "Nama"),
      controller: _namaCtrl,
    );
  }

  Widget _fieldAlamat() {
    return TextField(
      decoration: const InputDecoration(labelText: "Tanggal Lahir"),
      controller: _alamatCtrl,
    );
  }

  Widget _fieldNo_telpon() {
    return TextField(
      decoration: const InputDecoration(labelText: "Telepon"),
      controller: _no_telponCtrl,
    );
  }

  Widget _fieldJurusan() {
    return TextField(
      decoration: const InputDecoration(labelText: "Jurusan "),
      controller: _jurusanCtrl,
    );
  }

  Widget _fieldSemester() {
    return TextField(
      decoration: const InputDecoration(labelText: "Semester"),
      controller: _semesterCtrl,
    );
  }

  Widget _tombolSimpan() {
    return ElevatedButton(
      onPressed: () {
        Mahasiswa mahasiswa = Mahasiswa(
          nim: _nimCtrl.text,
          nama: _namaCtrl.text,
          alamat: _alamatCtrl.text,
          no_telpon: _no_telponCtrl.text,
          jurusan: _jurusanCtrl.text,
          semester: _semesterCtrl.text,
        );
        Navigator.pop(context);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => MahasiswaDetail(mahasiswa: mahasiswa),
          ),
        );
      },
      child: const Text("Simpan Perubahan"),
    );
  }
}
