import 'package:flutter/material.dart';
import '../model/mahasiswa.dart';
import 'mahasiswa_detail.dart';
import '../widget/sidebar.dart';
import 'mahasiswa_form.dart'; // Import file "Mahasiswa_form.dart" untuk digunakan pada saat menambah data Mahasiswa

class MahasiswaPage extends StatefulWidget {
  const MahasiswaPage({Key? key}); // Perbaikan penulisan parameter key

  @override
  _PageMahasiswaState createState() => _PageMahasiswaState();
}

class _PageMahasiswaState extends State<MahasiswaPage> {
  final List<Mahasiswa> _Mahasiswa = [
    Mahasiswa(
      nim: '1921189',
      nama: 'Adhwa Safina',
      alamat: 'Jl.Diponegoro No.56 ',
      no_telpon: '086382282919',
      jurusan: 'Sistem Informasi',
      semester: '4',
    ),
    Mahasiswa(
      nim: '19211273',
      nama: 'Andini Rahma ',
      alamat: 'Jl.Sudirman No.56 ',
      no_telpon: '085774261185',
      jurusan: '  Sistem Informasi',
      semester: '4',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Sidebar(),
      appBar: AppBar(
        title: const Text("Data Mahasiswa"),
        actions: [
          GestureDetector(
            child: const Icon(Icons.add),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MahasiswaForm()),
              );
            },
          ),
          GestureDetector(
            child: const Icon(Icons.search),
            onTap: () {
              // Lakukan aksi pencarian data sesuai abjad
              // ...
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: _Mahasiswa.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      MahasiswaDetail(mahasiswa: _Mahasiswa[index]),
                ),
              );
            },
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.grey,
                  width: 0.5,
                ),
              ),
              child: ListTile(
                title: Text(_Mahasiswa[index].nama),
                subtitle: Text('NIM: ${_Mahasiswa[index].nim}'),
              ),
            ),
          );
        },
      ),
    );
  }
}
