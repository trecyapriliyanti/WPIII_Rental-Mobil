import 'package:flutter/material.dart';
import '../model/jurusan.dart';
import 'jurusan_detail.dart';

class JurusanItem extends StatelessWidget {
  final Jurusan jurusan;
  const JurusanItem({super.key, required this.jurusan});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Card(
        child: ListTile(
          title: Text("${jurusan.namaJurusan}"),
        ),
      ),
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => JurusanDetail(jurusan: jurusan)));
      },
    );
  }
}
