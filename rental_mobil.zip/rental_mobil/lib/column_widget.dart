import 'package:flutter/material.dart';

class ColumnWidget extends StatelessWidget {
  const ColumnWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('widget column'),
        ),
        body: Column(
          children: const [
            Text('Kolom1'),
            Text('Kolom2'),
            Text('Kolom3'),
            Text('Kolom4')
          ],
        ));
  }
}
