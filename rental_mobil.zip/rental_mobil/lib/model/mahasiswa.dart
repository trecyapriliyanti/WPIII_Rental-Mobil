class Mahasiswa {
  String nim;
  String nama;
  final String alamat;
  final String no_telpon;
  final String jurusan;
  final String semester;

  Mahasiswa({
    required this.nim,
    required this.nama,
    required this.alamat,
    required this.no_telpon,
    required this.jurusan,
    required this.semester,
  });
}
