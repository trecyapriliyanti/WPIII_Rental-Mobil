class Jurusan {
  String namaJurusan;

  Jurusan({
    required this.namaJurusan,
  });
}
