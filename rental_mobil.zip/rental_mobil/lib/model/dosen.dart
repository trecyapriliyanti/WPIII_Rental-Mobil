class Dosen {
  String kd_dosen;
  String nama;
  final String pendidikan_terakhir;
  final String alamat;
  final String no_telp;
  String email;

  Dosen({
    required this.kd_dosen,
    required this.nama,
    required this.pendidikan_terakhir,
    required this.alamat,
    required this.no_telp,
    required this.email,
  });
}
