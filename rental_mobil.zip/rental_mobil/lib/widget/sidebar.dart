import 'package:flutter/material.dart';
import '../ui/beranda.dart';
import '../ui/login.dart';
import '../ui/jurusan_page.dart';
import '../ui/dosen_page.dart';
import '../ui/mahasiswa_page.dart';

class Sidebar extends StatelessWidget {
  const Sidebar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text("Admin"),
            accountEmail: Text("admin@admin.com"),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text("Beranda"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Beranda()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.school),
            title: Text("Mahasiswa"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MahasiswaPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.people),
            title: Text("Dosen "),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => DosenPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.book),
            title: Text("Jurusan"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => JurusanPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.logout_rounded),
            title: Text("Keluar"),
            onTap: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => Login()),
                (Route<dynamic> route) => false,
              );
            },
          ),
        ],
      ),
    );
  }
}
